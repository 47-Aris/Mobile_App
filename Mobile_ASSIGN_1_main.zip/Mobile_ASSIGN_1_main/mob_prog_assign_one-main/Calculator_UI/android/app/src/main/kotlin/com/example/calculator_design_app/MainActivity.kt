package com.example.calculator_design_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
