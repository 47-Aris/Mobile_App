Hello

Names:ISHIMWE Thierry Henry

Id:25319

Group:Tuesday(E1)

The  following are the screenshots of mobile programming first assignment of,

printing hello and designing a simple calculator using flutter under influence of VS Code and Android Studio



![hello](https://github.com/ishimwethierryhenry/mob_prog_assign_one/assets/149163309/608f3292-5b9d-4762-9a63-68dafded36df)
![Calculator](https://github.com/ishimwethierryhenry/mob_prog_assign_one/assets/149163309/0ca67f7c-7c42-4093-8e79-e9fd79576775)
